<?php
// Generate a secure encryption key
$encryption_key = base64_encode(random_bytes(32));

// Display the key
echo "Your encryption key: " . $encryption_key . "\n";
?>
